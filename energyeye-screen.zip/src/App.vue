
<template>
  <div style="background-color:#002344; color:white; height:100vh; padding:20px;">
    <h1>数字能源管理平台 - DEMO 大屏</h1>
    <div style="display:flex; flex-wrap:wrap; gap:20px;">
      <div style="flex:1; min-width:300px; background:#04355c; padding:10px;">仪表盘区域</div>
      <div style="flex:1; min-width:300px; background:#04355c; padding:10px;">用电统计图</div>
      <div style="flex:1; min-width:300px; background:#04355c; padding:10px;">设备运行状态</div>
      <div style="flex:1; min-width:300px; background:#04355c; padding:10px;">地图流程图</div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>
