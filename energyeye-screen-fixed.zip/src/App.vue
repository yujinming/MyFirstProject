
<template>
  <div style="background:#001d2e; color:white; height:100vh; display:flex; flex-direction:column; align-items:center; justify-content:center;">
    <h1 style="font-size:2em;">✅ 大屏已成功加载！</h1>
    <p>欢迎来到 EnergyEye Linux 系统大屏</p>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>
